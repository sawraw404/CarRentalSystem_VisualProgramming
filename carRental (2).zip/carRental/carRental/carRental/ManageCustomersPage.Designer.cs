﻿namespace carRental
{
    partial class ManageCustomersPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            customerIDTextBox = new TextBox();
            label7 = new Label();
            drivLicenseTextBox = new TextBox();
            deleteButton = new Button();
            updateButton = new Button();
            showButton = new Button();
            label6 = new Label();
            cnicTextBox = new TextBox();
            label5 = new Label();
            mobNumTextBox = new TextBox();
            label4 = new Label();
            addressTextBox = new TextBox();
            label3 = new Label();
            fullNameTextBox = new TextBox();
            addButton = new Button();
            label2 = new Label();
            dataGridView1 = new DataGridView();
            panel3 = new Panel();
            nextPageLabel = new Label();
            panel2 = new Panel();
            label8 = new Label();
            backButton = new PictureBox();
            label1 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)backButton).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(46, 97, 145);
            panel1.Controls.Add(customerIDTextBox);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(drivLicenseTextBox);
            panel1.Controls.Add(deleteButton);
            panel1.Controls.Add(updateButton);
            panel1.Controls.Add(showButton);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(cnicTextBox);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(mobNumTextBox);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(addressTextBox);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(fullNameTextBox);
            panel1.Controls.Add(addButton);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(dataGridView1);
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4, 4, 4, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1645, 936);
            panel1.TabIndex = 2;
            // 
            // customerIDTextBox
            // 
            customerIDTextBox.Anchor = AnchorStyles.None;
            customerIDTextBox.Location = new Point(216, 246);
            customerIDTextBox.Margin = new Padding(4, 4, 4, 4);
            customerIDTextBox.Multiline = true;
            customerIDTextBox.Name = "customerIDTextBox";
            customerIDTextBox.Size = new Size(293, 36);
            customerIDTextBox.TabIndex = 37;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(29, 246);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(169, 32);
            label7.TabIndex = 36;
            label7.Text = "Customer ID: *";
            // 
            // drivLicenseTextBox
            // 
            drivLicenseTextBox.Anchor = AnchorStyles.None;
            drivLicenseTextBox.Location = new Point(216, 595);
            drivLicenseTextBox.Margin = new Padding(4, 4, 4, 4);
            drivLicenseTextBox.Multiline = true;
            drivLicenseTextBox.Name = "drivLicenseTextBox";
            drivLicenseTextBox.Size = new Size(293, 36);
            drivLicenseTextBox.TabIndex = 35;
            // 
            // deleteButton
            // 
            deleteButton.Anchor = AnchorStyles.None;
            deleteButton.BackColor = Color.FromArgb(1, 30, 64);
            deleteButton.Font = new Font("Roboto Condensed", 11F, FontStyle.Bold, GraphicsUnit.Point);
            deleteButton.ForeColor = SystemColors.ButtonHighlight;
            deleteButton.Location = new Point(329, 800);
            deleteButton.Margin = new Padding(4, 4, 4, 4);
            deleteButton.Name = "deleteButton";
            deleteButton.Size = new Size(162, 52);
            deleteButton.TabIndex = 34;
            deleteButton.Text = "DELETE";
            deleteButton.UseVisualStyleBackColor = false;
            deleteButton.Click += deleteButton_Click;
            // 
            // updateButton
            // 
            updateButton.Anchor = AnchorStyles.None;
            updateButton.BackColor = Color.FromArgb(1, 30, 64);
            updateButton.Font = new Font("Roboto Condensed", 11F, FontStyle.Bold, GraphicsUnit.Point);
            updateButton.ForeColor = SystemColors.ButtonHighlight;
            updateButton.Location = new Point(38, 800);
            updateButton.Margin = new Padding(4, 4, 4, 4);
            updateButton.Name = "updateButton";
            updateButton.Size = new Size(162, 52);
            updateButton.TabIndex = 33;
            updateButton.Text = "UPDATE";
            updateButton.UseVisualStyleBackColor = false;
            updateButton.Click += updateButton_Click;
            // 
            // showButton
            // 
            showButton.Anchor = AnchorStyles.None;
            showButton.BackColor = Color.FromArgb(1, 30, 64);
            showButton.Font = new Font("Roboto Condensed", 11F, FontStyle.Bold, GraphicsUnit.Point);
            showButton.ForeColor = SystemColors.ButtonHighlight;
            showButton.Location = new Point(329, 694);
            showButton.Margin = new Padding(4, 4, 4, 4);
            showButton.Name = "showButton";
            showButton.Size = new Size(162, 52);
            showButton.TabIndex = 32;
            showButton.Text = "SHOW";
            showButton.UseVisualStyleBackColor = false;
            showButton.Click += showButton_Click;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(4, 590);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(198, 32);
            label6.TabIndex = 31;
            label6.Text = "Driving License: *";
            // 
            // cnicTextBox
            // 
            cnicTextBox.Anchor = AnchorStyles.None;
            cnicTextBox.Location = new Point(216, 526);
            cnicTextBox.Margin = new Padding(4, 4, 4, 4);
            cnicTextBox.Multiline = true;
            cnicTextBox.Name = "cnicTextBox";
            cnicTextBox.Size = new Size(293, 36);
            cnicTextBox.TabIndex = 30;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(109, 521);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(90, 32);
            label5.TabIndex = 29;
            label5.Text = "CNIC: *";
            // 
            // mobNumTextBox
            // 
            mobNumTextBox.Anchor = AnchorStyles.None;
            mobNumTextBox.Location = new Point(216, 458);
            mobNumTextBox.Margin = new Padding(4, 4, 4, 4);
            mobNumTextBox.Multiline = true;
            mobNumTextBox.Name = "mobNumTextBox";
            mobNumTextBox.Size = new Size(293, 36);
            mobNumTextBox.TabIndex = 28;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(26, 452);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(171, 32);
            label4.TabIndex = 27;
            label4.Text = "Mobile Num: *";
            // 
            // addressTextBox
            // 
            addressTextBox.Anchor = AnchorStyles.None;
            addressTextBox.Location = new Point(216, 389);
            addressTextBox.Margin = new Padding(4, 4, 4, 4);
            addressTextBox.Multiline = true;
            addressTextBox.Name = "addressTextBox";
            addressTextBox.Size = new Size(293, 36);
            addressTextBox.TabIndex = 26;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(76, 389);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(110, 32);
            label3.TabIndex = 25;
            label3.Text = "Address: ";
            // 
            // fullNameTextBox
            // 
            fullNameTextBox.Anchor = AnchorStyles.None;
            fullNameTextBox.Location = new Point(216, 319);
            fullNameTextBox.Margin = new Padding(4, 4, 4, 4);
            fullNameTextBox.Multiline = true;
            fullNameTextBox.Name = "fullNameTextBox";
            fullNameTextBox.Size = new Size(293, 36);
            fullNameTextBox.TabIndex = 24;
            // 
            // addButton
            // 
            addButton.Anchor = AnchorStyles.None;
            addButton.BackColor = Color.FromArgb(1, 30, 64);
            addButton.Font = new Font("Roboto Condensed", 11F, FontStyle.Bold, GraphicsUnit.Point);
            addButton.ForeColor = SystemColors.ButtonHighlight;
            addButton.Location = new Point(38, 694);
            addButton.Margin = new Padding(4, 4, 4, 4);
            addButton.Name = "addButton";
            addButton.Size = new Size(162, 52);
            addButton.TabIndex = 20;
            addButton.Text = "ADD";
            addButton.UseVisualStyleBackColor = false;
            addButton.Click += addButton_Click;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(54, 319);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(145, 32);
            label2.TabIndex = 13;
            label2.Text = "Full Name: *";
            // 
            // dataGridView1
            // 
            dataGridView1.Anchor = AnchorStyles.None;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(558, 246);
            dataGridView1.Margin = new Padding(4, 4, 4, 4);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 29;
            dataGridView1.Size = new Size(1046, 610);
            dataGridView1.TabIndex = 9;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(1, 30, 64);
            panel3.Controls.Add(nextPageLabel);
            panel3.Dock = DockStyle.Bottom;
            panel3.Location = new Point(0, 888);
            panel3.Margin = new Padding(4, 4, 4, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(1645, 48);
            panel3.TabIndex = 8;
            // 
            // nextPageLabel
            // 
            nextPageLabel.Anchor = AnchorStyles.Top;
            nextPageLabel.AutoSize = true;
            nextPageLabel.Font = new Font("Segoe UI Light", 12F, FontStyle.Regular, GraphicsUnit.Point);
            nextPageLabel.ForeColor = SystemColors.ControlLight;
            nextPageLabel.Location = new Point(1449, 4);
            nextPageLabel.Margin = new Padding(4, 0, 4, 0);
            nextPageLabel.Name = "nextPageLabel";
            nextPageLabel.Size = new Size(155, 32);
            nextPageLabel.TabIndex = 17;
            nextPageLabel.Text = "Next Page >>";
            nextPageLabel.Click += nextPageLabel_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(69, 19, 54);
            panel2.Controls.Add(label8);
            panel2.Controls.Add(backButton);
            panel2.Controls.Add(label1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(4, 4, 4, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(1645, 143);
            panel2.TabIndex = 7;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.Top;
            label8.AutoSize = true;
            label8.Font = new Font("Roboto Condensed", 20F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = SystemColors.ControlLight;
            label8.Location = new Point(605, 31);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(461, 48);
            label8.TabIndex = 16;
            label8.Text = "THE CAR RENTAL SYSTAM ";
            // 
            // backButton
            // 
            backButton.Image = Properties.Resources.backarrow;
            backButton.Location = new Point(4, 11);
            backButton.Margin = new Padding(4, 4, 4, 4);
            backButton.Name = "backButton";
            backButton.Size = new Size(44, 40);
            backButton.SizeMode = PictureBoxSizeMode.StretchImage;
            backButton.TabIndex = 14;
            backButton.TabStop = false;
            backButton.Click += backButton_Click;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top;
            label1.AutoSize = true;
            label1.Font = new Font("Roboto Condensed", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.ControlLight;
            label1.Location = new Point(712, 90);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(268, 34);
            label1.TabIndex = 12;
            label1.Text = "MANAGE CUSTOMERS";
            // 
            // ManageCustomersPage
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1645, 936);
            Controls.Add(panel1);
            Margin = new Padding(4, 4, 4, 4);
            Name = "ManageCustomersPage";
            Text = "ManageCustomersPage";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)backButton).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button deleteButton;
        private Button updateButton;
        private Button showButton;
        private Label label6;
        private TextBox cnicTextBox;
        private Label label5;
        private TextBox mobNumTextBox;
        private Label label4;
        private TextBox addressTextBox;
        private Label label3;
        private TextBox fullNameTextBox;
        private Button addButton;
        private Label label2;
        private DataGridView dataGridView1;
        private Panel panel3;
        private Panel panel2;
        private PictureBox backButton;
        private Label label1;
        private TextBox drivLicenseTextBox;
        private TextBox customerIDTextBox;
        private Label label7;
        private Label label8;
        private Label nextPageLabel;
    }
}