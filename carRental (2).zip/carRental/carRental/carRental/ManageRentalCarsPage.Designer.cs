﻿namespace carRental
{
    partial class ManageRentalCarsPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            generateBill = new Button();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            carIDTextBox = new TextBox();
            rentCarsGrid = new DataGridView();
            endDatePicker = new DateTimePicker();
            startDatePicker = new DateTimePicker();
            label7 = new Label();
            fuelTypeComboBox = new ComboBox();
            carTypeComboBox = new ComboBox();
            customerIDTextBox = new TextBox();
            deleteButton = new Button();
            showButton = new Button();
            label6 = new Label();
            label5 = new Label();
            rentIDTextBox = new TextBox();
            label4 = new Label();
            label3 = new Label();
            addButton = new Button();
            label2 = new Label();
            carsInfoGrid = new DataGridView();
            panel3 = new Panel();
            backPageLabel = new Label();
            nextPageLabel = new Label();
            panel2 = new Panel();
            label8 = new Label();
            label1 = new Label();
            backButton = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)rentCarsGrid).BeginInit();
            ((System.ComponentModel.ISupportInitialize)carsInfoGrid).BeginInit();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)backButton).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(46, 97, 145);
            panel1.Controls.Add(generateBill);
            panel1.Controls.Add(label12);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(carIDTextBox);
            panel1.Controls.Add(rentCarsGrid);
            panel1.Controls.Add(endDatePicker);
            panel1.Controls.Add(startDatePicker);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(fuelTypeComboBox);
            panel1.Controls.Add(carTypeComboBox);
            panel1.Controls.Add(customerIDTextBox);
            panel1.Controls.Add(deleteButton);
            panel1.Controls.Add(showButton);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(rentIDTextBox);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(addButton);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(carsInfoGrid);
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4, 4, 4, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1645, 936);
            panel1.TabIndex = 3;
            // 
            // generateBill
            // 
            generateBill.BackColor = Color.FromArgb(1, 30, 64);
            generateBill.Font = new Font("Roboto Condensed", 11F, FontStyle.Bold, GraphicsUnit.Point);
            generateBill.ForeColor = SystemColors.ButtonHighlight;
            generateBill.Location = new Point(342, 820);
            generateBill.Margin = new Padding(4, 4, 4, 4);
            generateBill.Name = "generateBill";
            generateBill.Size = new Size(184, 52);
            generateBill.TabIndex = 51;
            generateBill.Text = "GENERATE BILL";
            generateBill.UseVisualStyleBackColor = false;
            generateBill.Click += generateBill_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label12.ForeColor = SystemColors.ControlText;
            label12.Location = new Point(1078, 520);
            label12.Margin = new Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new Size(140, 38);
            label12.TabIndex = 50;
            label12.Text = "Rent Cars";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label11.ForeColor = SystemColors.ControlText;
            label11.Location = new Point(1023, 165);
            label11.Margin = new Padding(4, 0, 4, 0);
            label11.Name = "label11";
            label11.Size = new Size(239, 38);
            label11.TabIndex = 49;
            label11.Text = "Cars Information";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label10.Location = new Point(94, 459);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new Size(101, 32);
            label10.TabIndex = 48;
            label10.Text = "Car ID: *";
            // 
            // carIDTextBox
            // 
            carIDTextBox.Location = new Point(232, 464);
            carIDTextBox.Margin = new Padding(4, 4, 4, 4);
            carIDTextBox.Multiline = true;
            carIDTextBox.Name = "carIDTextBox";
            carIDTextBox.Size = new Size(293, 36);
            carIDTextBox.TabIndex = 47;
            // 
            // rentCarsGrid
            // 
            rentCarsGrid.BackgroundColor = SystemColors.ButtonHighlight;
            rentCarsGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            rentCarsGrid.Location = new Point(573, 572);
            rentCarsGrid.Margin = new Padding(4, 4, 4, 4);
            rentCarsGrid.Name = "rentCarsGrid";
            rentCarsGrid.RowHeadersWidth = 51;
            rentCarsGrid.RowTemplate.Height = 29;
            rentCarsGrid.Size = new Size(1072, 300);
            rentCarsGrid.TabIndex = 46;
            rentCarsGrid.CellClick += rentCarsGrid_CellClick;
            // 
            // endDatePicker
            // 
            endDatePicker.Location = new Point(198, 660);
            endDatePicker.Margin = new Padding(4, 4, 4, 4);
            endDatePicker.Name = "endDatePicker";
            endDatePicker.Size = new Size(328, 31);
            endDatePicker.TabIndex = 43;
            // 
            // startDatePicker
            // 
            startDatePicker.Location = new Point(198, 598);
            startDatePicker.Margin = new Padding(4, 4, 4, 4);
            startDatePicker.Name = "startDatePicker";
            startDatePicker.Size = new Size(328, 31);
            startDatePicker.TabIndex = 42;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(31, 392);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(162, 32);
            label7.TabIndex = 41;
            label7.Text = "CustomerID: *";
            // 
            // fuelTypeComboBox
            // 
            fuelTypeComboBox.FormattingEnabled = true;
            fuelTypeComboBox.Items.AddRange(new object[] { "Petrol", "Diesel", "Hybrid", "Electric" });
            fuelTypeComboBox.Location = new Point(232, 268);
            fuelTypeComboBox.Margin = new Padding(4, 4, 4, 4);
            fuelTypeComboBox.Name = "fuelTypeComboBox";
            fuelTypeComboBox.Size = new Size(293, 33);
            fuelTypeComboBox.TabIndex = 38;
            // 
            // carTypeComboBox
            // 
            carTypeComboBox.FormattingEnabled = true;
            carTypeComboBox.Items.AddRange(new object[] { "Family", "City", "Sports" });
            carTypeComboBox.Location = new Point(232, 202);
            carTypeComboBox.Margin = new Padding(4, 4, 4, 4);
            carTypeComboBox.Name = "carTypeComboBox";
            carTypeComboBox.Size = new Size(293, 33);
            carTypeComboBox.TabIndex = 37;
            // 
            // customerIDTextBox
            // 
            customerIDTextBox.Location = new Point(232, 398);
            customerIDTextBox.Margin = new Padding(4, 4, 4, 4);
            customerIDTextBox.Multiline = true;
            customerIDTextBox.Name = "customerIDTextBox";
            customerIDTextBox.Size = new Size(293, 36);
            customerIDTextBox.TabIndex = 36;
            // 
            // deleteButton
            // 
            deleteButton.BackColor = Color.FromArgb(1, 30, 64);
            deleteButton.Font = new Font("Roboto Condensed", 11F, FontStyle.Bold, GraphicsUnit.Point);
            deleteButton.ForeColor = SystemColors.ButtonHighlight;
            deleteButton.Location = new Point(51, 820);
            deleteButton.Margin = new Padding(4, 4, 4, 4);
            deleteButton.Name = "deleteButton";
            deleteButton.Size = new Size(181, 52);
            deleteButton.TabIndex = 34;
            deleteButton.Text = "DELETE";
            deleteButton.UseVisualStyleBackColor = false;
            deleteButton.Click += deleteButton_Click;
            // 
            // showButton
            // 
            showButton.BackColor = Color.FromArgb(1, 30, 64);
            showButton.Font = new Font("Roboto Condensed", 11F, FontStyle.Bold, GraphicsUnit.Point);
            showButton.ForeColor = SystemColors.ButtonHighlight;
            showButton.Location = new Point(342, 742);
            showButton.Margin = new Padding(4, 4, 4, 4);
            showButton.Name = "showButton";
            showButton.Size = new Size(183, 52);
            showButton.TabIndex = 32;
            showButton.Text = "SHOW";
            showButton.UseVisualStyleBackColor = false;
            showButton.Click += showButton_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(40, 658);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(138, 32);
            label6.TabIndex = 31;
            label6.Text = "Return date";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(40, 589);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(137, 32);
            label5.TabIndex = 29;
            label5.Text = "Rental Date";
            // 
            // rentIDTextBox
            // 
            rentIDTextBox.Location = new Point(232, 331);
            rentIDTextBox.Margin = new Padding(4, 4, 4, 4);
            rentIDTextBox.Multiline = true;
            rentIDTextBox.Name = "rentIDTextBox";
            rentIDTextBox.Size = new Size(293, 36);
            rentIDTextBox.TabIndex = 28;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(81, 331);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(114, 32);
            label4.TabIndex = 27;
            label4.Text = "Rent ID: *";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(58, 268);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(139, 32);
            label3.TabIndex = 25;
            label3.Text = "Fuel Type: *";
            // 
            // addButton
            // 
            addButton.BackColor = Color.FromArgb(1, 30, 64);
            addButton.Font = new Font("Roboto Condensed", 11F, FontStyle.Bold, GraphicsUnit.Point);
            addButton.ForeColor = SystemColors.ButtonHighlight;
            addButton.Location = new Point(51, 742);
            addButton.Margin = new Padding(4, 4, 4, 4);
            addButton.Name = "addButton";
            addButton.Size = new Size(181, 52);
            addButton.TabIndex = 20;
            addButton.Text = "ADD";
            addButton.UseVisualStyleBackColor = false;
            addButton.Click += addButton_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(66, 198);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(129, 32);
            label2.TabIndex = 13;
            label2.Text = "Car Type: *";
            // 
            // carsInfoGrid
            // 
            carsInfoGrid.BackgroundColor = SystemColors.ButtonHighlight;
            carsInfoGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            carsInfoGrid.Location = new Point(573, 220);
            carsInfoGrid.Margin = new Padding(4, 4, 4, 4);
            carsInfoGrid.Name = "carsInfoGrid";
            carsInfoGrid.RowHeadersWidth = 51;
            carsInfoGrid.RowTemplate.Height = 29;
            carsInfoGrid.Size = new Size(1072, 280);
            carsInfoGrid.TabIndex = 9;
            carsInfoGrid.CellClick += carsInfoGrid_CellClick;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(1, 30, 64);
            panel3.Controls.Add(backPageLabel);
            panel3.Controls.Add(nextPageLabel);
            panel3.Dock = DockStyle.Bottom;
            panel3.Location = new Point(0, 888);
            panel3.Margin = new Padding(4, 4, 4, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(1645, 48);
            panel3.TabIndex = 8;
            // 
            // backPageLabel
            // 
            backPageLabel.Anchor = AnchorStyles.Top;
            backPageLabel.AutoSize = true;
            backPageLabel.Font = new Font("Segoe UI Light", 12F, FontStyle.Regular, GraphicsUnit.Point);
            backPageLabel.ForeColor = SystemColors.ControlLight;
            backPageLabel.Location = new Point(38, 4);
            backPageLabel.Margin = new Padding(4, 0, 4, 0);
            backPageLabel.Name = "backPageLabel";
            backPageLabel.Size = new Size(156, 32);
            backPageLabel.TabIndex = 21;
            backPageLabel.Text = "<< Back Page";
            backPageLabel.Click += backPageLabel_Click;
            // 
            // nextPageLabel
            // 
            nextPageLabel.Anchor = AnchorStyles.Top;
            nextPageLabel.AutoSize = true;
            nextPageLabel.Font = new Font("Segoe UI Light", 12F, FontStyle.Regular, GraphicsUnit.Point);
            nextPageLabel.ForeColor = SystemColors.ControlLight;
            nextPageLabel.Location = new Point(1449, 4);
            nextPageLabel.Margin = new Padding(4, 0, 4, 0);
            nextPageLabel.Name = "nextPageLabel";
            nextPageLabel.Size = new Size(155, 32);
            nextPageLabel.TabIndex = 18;
            nextPageLabel.Text = "Next Page >>";
            nextPageLabel.Click += nextPageLabel_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(69, 19, 54);
            panel2.Controls.Add(label8);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(backButton);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(4, 4, 4, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(1645, 143);
            panel2.TabIndex = 7;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.Top;
            label8.AutoSize = true;
            label8.Font = new Font("Roboto Condensed", 20F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = SystemColors.ControlLight;
            label8.Location = new Point(569, 27);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(461, 48);
            label8.TabIndex = 18;
            label8.Text = "THE CAR RENTAL SYSTAM ";
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top;
            label1.AutoSize = true;
            label1.Font = new Font("Roboto Condensed", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.ControlLight;
            label1.Location = new Point(712, 84);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(200, 34);
            label1.TabIndex = 17;
            label1.Text = "MANAGE RENTS";
            // 
            // backButton
            // 
            backButton.Image = Properties.Resources.backarrow;
            backButton.Location = new Point(4, 11);
            backButton.Margin = new Padding(4, 4, 4, 4);
            backButton.Name = "backButton";
            backButton.Size = new Size(44, 40);
            backButton.SizeMode = PictureBoxSizeMode.StretchImage;
            backButton.TabIndex = 14;
            backButton.TabStop = false;
            backButton.Click += backButton_Click;
            // 
            // ManageRentalCarsPage
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1645, 936);
            Controls.Add(panel1);
            Margin = new Padding(4, 4, 4, 4);
            Name = "ManageRentalCarsPage";
            Text = "ManageRentalCarsPage";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)rentCarsGrid).EndInit();
            ((System.ComponentModel.ISupportInitialize)carsInfoGrid).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)backButton).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private TextBox customerIDTextBox;
        private Button deleteButton;
        private Button showButton;
        private Label label6;
        private Label label5;
        private TextBox rentIDTextBox;
        private Label label4;
        private Label label3;
        private Button addButton;
        private Label label2;
        private DataGridView carsInfoGrid;
        private Panel panel3;
        private Panel panel2;
        private PictureBox backButton;
        private ComboBox fuelTypeComboBox;
        private ComboBox carTypeComboBox;
        private Label label7;
        private DateTimePicker endDatePicker;
        private DateTimePicker startDatePicker;
        private Label label10;
        private TextBox carIDTextBox;
        private DataGridView rentCarsGrid;
        private Label label11;
        private Button generateBill;
        private Label label12;
        private Label label8;
        private Label label1;
        private Label nextPageLabel;
        private Label backPageLabel;
    }
}