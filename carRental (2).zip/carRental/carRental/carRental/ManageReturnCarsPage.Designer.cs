﻿namespace carRental
{
    partial class ManageReturnCarsPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            carIDTextBox = new TextBox();
            label7 = new Label();
            returnIDTextBox = new TextBox();
            label2 = new Label();
            generateBill = new Button();
            label12 = new Label();
            label11 = new Label();
            returnCarsGrid = new DataGridView();
            returnDatePicker = new DateTimePicker();
            deleteButton = new Button();
            showButton = new Button();
            label5 = new Label();
            rentIDTextBox = new TextBox();
            label4 = new Label();
            addButton = new Button();
            rentInfoGrid = new DataGridView();
            panel3 = new Panel();
            backPageLabel = new Label();
            panel2 = new Panel();
            label8 = new Label();
            label1 = new Label();
            backButton = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)returnCarsGrid).BeginInit();
            ((System.ComponentModel.ISupportInitialize)rentInfoGrid).BeginInit();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)backButton).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(46, 97, 145);
            panel1.Controls.Add(carIDTextBox);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(returnIDTextBox);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(generateBill);
            panel1.Controls.Add(label12);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(returnCarsGrid);
            panel1.Controls.Add(returnDatePicker);
            panel1.Controls.Add(deleteButton);
            panel1.Controls.Add(showButton);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(rentIDTextBox);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(addButton);
            panel1.Controls.Add(rentInfoGrid);
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4, 4, 4, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1645, 936);
            panel1.TabIndex = 4;
            // 
            // carIDTextBox
            // 
            carIDTextBox.Location = new Point(232, 222);
            carIDTextBox.Margin = new Padding(4, 4, 4, 4);
            carIDTextBox.Multiline = true;
            carIDTextBox.Name = "carIDTextBox";
            carIDTextBox.Size = new Size(293, 36);
            carIDTextBox.TabIndex = 55;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(94, 222);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(101, 32);
            label7.TabIndex = 54;
            label7.Text = "Car ID: *";
            // 
            // returnIDTextBox
            // 
            returnIDTextBox.Location = new Point(232, 290);
            returnIDTextBox.Margin = new Padding(4, 4, 4, 4);
            returnIDTextBox.Multiline = true;
            returnIDTextBox.Name = "returnIDTextBox";
            returnIDTextBox.Size = new Size(293, 36);
            returnIDTextBox.TabIndex = 53;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(59, 290);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(136, 32);
            label2.TabIndex = 52;
            label2.Text = "Return ID: *";
            // 
            // generateBill
            // 
            generateBill.BackColor = Color.FromArgb(1, 30, 64);
            generateBill.Font = new Font("Roboto Condensed", 11F, FontStyle.Bold, GraphicsUnit.Point);
            generateBill.ForeColor = SystemColors.ButtonHighlight;
            generateBill.Location = new Point(342, 820);
            generateBill.Margin = new Padding(4, 4, 4, 4);
            generateBill.Name = "generateBill";
            generateBill.Size = new Size(184, 52);
            generateBill.TabIndex = 51;
            generateBill.Text = "GENERATE BILL";
            generateBill.UseVisualStyleBackColor = false;
            generateBill.Click += generateBill_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label12.ForeColor = SystemColors.ControlText;
            label12.Location = new Point(1008, 515);
            label12.Margin = new Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new Size(200, 38);
            label12.TabIndex = 50;
            label12.Text = "Returned Cars";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label11.ForeColor = SystemColors.ControlText;
            label11.Location = new Point(1008, 163);
            label11.Margin = new Padding(4, 0, 4, 0);
            label11.Name = "label11";
            label11.Size = new Size(186, 38);
            label11.TabIndex = 49;
            label11.Text = "Cars On Rent";
            // 
            // returnCarsGrid
            // 
            returnCarsGrid.BackgroundColor = SystemColors.ButtonHighlight;
            returnCarsGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            returnCarsGrid.Location = new Point(573, 572);
            returnCarsGrid.Margin = new Padding(4, 4, 4, 4);
            returnCarsGrid.Name = "returnCarsGrid";
            returnCarsGrid.RowHeadersWidth = 51;
            returnCarsGrid.RowTemplate.Height = 29;
            returnCarsGrid.Size = new Size(1072, 300);
            returnCarsGrid.TabIndex = 46;
            // 
            // returnDatePicker
            // 
            returnDatePicker.Location = new Point(232, 428);
            returnDatePicker.Margin = new Padding(4, 4, 4, 4);
            returnDatePicker.Name = "returnDatePicker";
            returnDatePicker.Size = new Size(328, 31);
            returnDatePicker.TabIndex = 42;
            // 
            // deleteButton
            // 
            deleteButton.BackColor = Color.FromArgb(1, 30, 64);
            deleteButton.Font = new Font("Roboto Condensed", 11F, FontStyle.Bold, GraphicsUnit.Point);
            deleteButton.ForeColor = SystemColors.ButtonHighlight;
            deleteButton.Location = new Point(51, 820);
            deleteButton.Margin = new Padding(4, 4, 4, 4);
            deleteButton.Name = "deleteButton";
            deleteButton.Size = new Size(184, 52);
            deleteButton.TabIndex = 34;
            deleteButton.Text = "DELETE";
            deleteButton.UseVisualStyleBackColor = false;
            deleteButton.Click += deleteButton_Click;
            // 
            // showButton
            // 
            showButton.BackColor = Color.FromArgb(1, 30, 64);
            showButton.Font = new Font("Roboto Condensed", 11F, FontStyle.Bold, GraphicsUnit.Point);
            showButton.ForeColor = SystemColors.ButtonHighlight;
            showButton.Location = new Point(342, 742);
            showButton.Margin = new Padding(4, 4, 4, 4);
            showButton.Name = "showButton";
            showButton.Size = new Size(184, 52);
            showButton.TabIndex = 32;
            showButton.Text = "SHOW";
            showButton.UseVisualStyleBackColor = false;
            showButton.Click += showButton_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(41, 425);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(153, 32);
            label5.TabIndex = 29;
            label5.Text = "Delay Date: *";
            // 
            // rentIDTextBox
            // 
            rentIDTextBox.Location = new Point(232, 358);
            rentIDTextBox.Margin = new Padding(4, 4, 4, 4);
            rentIDTextBox.Multiline = true;
            rentIDTextBox.Name = "rentIDTextBox";
            rentIDTextBox.Size = new Size(293, 36);
            rentIDTextBox.TabIndex = 28;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(81, 358);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(114, 32);
            label4.TabIndex = 27;
            label4.Text = "Rent ID: *";
            // 
            // addButton
            // 
            addButton.BackColor = Color.FromArgb(1, 30, 64);
            addButton.Font = new Font("Roboto Condensed", 11F, FontStyle.Bold, GraphicsUnit.Point);
            addButton.ForeColor = SystemColors.ButtonHighlight;
            addButton.Location = new Point(51, 742);
            addButton.Margin = new Padding(4, 4, 4, 4);
            addButton.Name = "addButton";
            addButton.Size = new Size(184, 52);
            addButton.TabIndex = 20;
            addButton.Text = "ADD";
            addButton.UseVisualStyleBackColor = false;
            addButton.Click += addButton_Click;
            // 
            // rentInfoGrid
            // 
            rentInfoGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            rentInfoGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            rentInfoGrid.BackgroundColor = SystemColors.ButtonHighlight;
            rentInfoGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            rentInfoGrid.Location = new Point(573, 205);
            rentInfoGrid.Margin = new Padding(4, 4, 4, 4);
            rentInfoGrid.Name = "rentInfoGrid";
            rentInfoGrid.RowHeadersWidth = 51;
            rentInfoGrid.RowTemplate.Height = 29;
            rentInfoGrid.Size = new Size(1072, 280);
            rentInfoGrid.TabIndex = 9;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(1, 30, 64);
            panel3.Controls.Add(backPageLabel);
            panel3.Dock = DockStyle.Bottom;
            panel3.Location = new Point(0, 888);
            panel3.Margin = new Padding(4, 4, 4, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(1645, 48);
            panel3.TabIndex = 8;
            // 
            // backPageLabel
            // 
            backPageLabel.Anchor = AnchorStyles.Top;
            backPageLabel.AutoSize = true;
            backPageLabel.Font = new Font("Segoe UI Light", 12F, FontStyle.Regular, GraphicsUnit.Point);
            backPageLabel.ForeColor = SystemColors.ControlLight;
            backPageLabel.Location = new Point(38, 4);
            backPageLabel.Margin = new Padding(4, 0, 4, 0);
            backPageLabel.Name = "backPageLabel";
            backPageLabel.Size = new Size(156, 32);
            backPageLabel.TabIndex = 20;
            backPageLabel.Text = "<< Back Page";
            backPageLabel.Click += backPageLabel_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(69, 19, 54);
            panel2.Controls.Add(label8);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(backButton);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(4, 4, 4, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(1645, 143);
            panel2.TabIndex = 7;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.Top;
            label8.AutoSize = true;
            label8.Font = new Font("Roboto Condensed", 20F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = SystemColors.ControlLight;
            label8.Location = new Point(600, 28);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(461, 48);
            label8.TabIndex = 20;
            label8.Text = "THE CAR RENTAL SYSTAM ";
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top;
            label1.AutoSize = true;
            label1.Font = new Font("Roboto Condensed", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.ControlLight;
            label1.Location = new Point(727, 88);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(232, 34);
            label1.TabIndex = 19;
            label1.Text = "MANAGE RETURNS";
            // 
            // backButton
            // 
            backButton.Image = Properties.Resources.backarrow;
            backButton.Location = new Point(4, 11);
            backButton.Margin = new Padding(4, 4, 4, 4);
            backButton.Name = "backButton";
            backButton.Size = new Size(44, 40);
            backButton.SizeMode = PictureBoxSizeMode.StretchImage;
            backButton.TabIndex = 14;
            backButton.TabStop = false;
            backButton.Click += backButton_Click;
            // 
            // ManageReturnCarsPage
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1645, 936);
            Controls.Add(panel1);
            Margin = new Padding(4, 4, 4, 4);
            Name = "ManageReturnCarsPage";
            Text = "ManageReturnCars";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)returnCarsGrid).EndInit();
            ((System.ComponentModel.ISupportInitialize)rentInfoGrid).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)backButton).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button generateBill;
        private Label label12;
        private Label label11;
        private DataGridView returnCarsGrid;
        private Label label9;
        private TextBox regNumTextBox;
        private DateTimePicker endDatePicker;
        private DateTimePicker returnDatePicker;
        private ComboBox fuelTypeComboBox;
        private ComboBox carTypeComboBox;
        private Button deleteButton;
        private Button showButton;
        private Label label5;
        private TextBox rentIDTextBox;
        private Label label4;
        private Label label3;
        private Button addButton;
        private DataGridView rentInfoGrid;
        private Panel panel3;
        private Panel panel2;
        private PictureBox backButton;
        private TextBox returnIDTextBox;
        private Label label2;
        private TextBox carIDTextBox;
        private Label label7;
        private Label label8;
        private Label label1;
        private Label backPageLabel;
    }
}