﻿namespace carRental
{
    partial class RentBillPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            panel6 = new Panel();
            label15 = new Label();
            label16 = new Label();
            groupBox1 = new GroupBox();
            panel4 = new Panel();
            panel2 = new Panel();
            panel5 = new Panel();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label9 = new Label();
            advancePaymentLabel = new Label();
            label10 = new Label();
            label8 = new Label();
            rentDateLabel = new Label();
            label19 = new Label();
            returnDateLabel = new Label();
            label23 = new Label();
            totalPriceLabel = new Label();
            label22 = new Label();
            brandLabel = new Label();
            label24 = new Label();
            regNumLabel = new Label();
            label21 = new Label();
            driveLicenseLabel = new Label();
            label20 = new Label();
            label7 = new Label();
            label29 = new Label();
            label6 = new Label();
            label28 = new Label();
            label5 = new Label();
            fullNameLabel = new Label();
            label4 = new Label();
            addressLabel = new Label();
            label2 = new Label();
            mobNumLabel = new Label();
            label1 = new Label();
            cnicLabel = new Label();
            fuelTypeLabel = new Label();
            modelLabel = new Label();
            carTypeLabel = new Label();
            pricePerDayLabel = new Label();
            saveBillButton = new Button();
            viewBillButton = new Button();
            label3 = new Label();
            rentIDTextBox = new TextBox();
            panel3 = new Panel();
            panel1.SuspendLayout();
            panel6.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(1, 30, 64);
            panel1.Controls.Add(panel6);
            panel1.Controls.Add(groupBox1);
            panel1.Controls.Add(saveBillButton);
            panel1.Controls.Add(viewBillButton);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(rentIDTextBox);
            panel1.Controls.Add(panel3);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1645, 936);
            panel1.TabIndex = 6;
            // 
            // panel6
            // 
            panel6.BackColor = Color.FromArgb(69, 19, 54);
            panel6.Controls.Add(label15);
            panel6.Controls.Add(label16);
            panel6.Dock = DockStyle.Top;
            panel6.Location = new Point(0, 0);
            panel6.Margin = new Padding(4);
            panel6.Name = "panel6";
            panel6.Size = new Size(1645, 138);
            panel6.TabIndex = 9;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Roboto Condensed", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label15.ForeColor = SystemColors.ControlLight;
            label15.Location = new Point(754, 85);
            label15.Margin = new Padding(4, 0, 4, 0);
            label15.Name = "label15";
            label15.Size = new Size(154, 34);
            label15.TabIndex = 52;
            label15.Text = "Car Rent Bill";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Roboto Condensed", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label16.ForeColor = SystemColors.ControlLight;
            label16.Location = new Point(660, 31);
            label16.Margin = new Padding(4, 0, 4, 0);
            label16.Name = "label16";
            label16.Size = new Size(337, 43);
            label16.TabIndex = 51;
            label16.Text = "CAR RENTAL SYSTEM";
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.FromArgb(46, 97, 145);
            groupBox1.Controls.Add(panel4);
            groupBox1.Controls.Add(panel2);
            groupBox1.Controls.Add(panel5);
            groupBox1.Controls.Add(label14);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(advancePaymentLabel);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(rentDateLabel);
            groupBox1.Controls.Add(label19);
            groupBox1.Controls.Add(returnDateLabel);
            groupBox1.Controls.Add(label23);
            groupBox1.Controls.Add(totalPriceLabel);
            groupBox1.Controls.Add(label22);
            groupBox1.Controls.Add(brandLabel);
            groupBox1.Controls.Add(label24);
            groupBox1.Controls.Add(regNumLabel);
            groupBox1.Controls.Add(label21);
            groupBox1.Controls.Add(driveLicenseLabel);
            groupBox1.Controls.Add(label20);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label29);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label28);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(fullNameLabel);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(addressLabel);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(mobNumLabel);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(cnicLabel);
            groupBox1.Controls.Add(fuelTypeLabel);
            groupBox1.Controls.Add(modelLabel);
            groupBox1.Controls.Add(carTypeLabel);
            groupBox1.Controls.Add(pricePerDayLabel);
            groupBox1.Font = new Font("Roboto Condensed", 14F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.ForeColor = SystemColors.ButtonHighlight;
            groupBox1.Location = new Point(514, 184);
            groupBox1.Margin = new Padding(4);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4);
            groupBox1.Size = new Size(1116, 698);
            groupBox1.TabIndex = 49;
            groupBox1.TabStop = false;
            groupBox1.Text = "  YOUR BILL  ";
            // 
            // panel4
            // 
            panel4.BackColor = SystemColors.ButtonHighlight;
            panel4.Location = new Point(29, 594);
            panel4.Margin = new Padding(4);
            panel4.Name = "panel4";
            panel4.Size = new Size(1042, 1);
            panel4.TabIndex = 81;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ButtonHighlight;
            panel2.Location = new Point(29, 444);
            panel2.Margin = new Padding(4);
            panel2.Name = "panel2";
            panel2.Size = new Size(1042, 1);
            panel2.TabIndex = 80;
            // 
            // panel5
            // 
            panel5.BackColor = SystemColors.ButtonHighlight;
            panel5.Location = new Point(29, 238);
            panel5.Margin = new Padding(4);
            panel5.Name = "panel5";
            panel5.Size = new Size(1042, 1);
            panel5.TabIndex = 79;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Roboto Condensed", 13F, FontStyle.Bold, GraphicsUnit.Point);
            label14.Location = new Point(29, 469);
            label14.Margin = new Padding(4, 0, 4, 0);
            label14.Name = "label14";
            label14.Size = new Size(147, 32);
            label14.TabIndex = 78;
            label14.Text = "Rent Details:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Roboto Condensed", 13F, FontStyle.Bold, GraphicsUnit.Point);
            label13.Location = new Point(29, 262);
            label13.Margin = new Padding(4, 0, 4, 0);
            label13.Name = "label13";
            label13.Size = new Size(136, 32);
            label13.TabIndex = 77;
            label13.Text = "Car Details:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label12.Location = new Point(889, 401);
            label12.Margin = new Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new Size(24, 25);
            label12.TabIndex = 76;
            label12.Text = "$";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Times New Roman", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(285, 640);
            label11.Margin = new Padding(4, 0, 4, 0);
            label11.Name = "label11";
            label11.Size = new Size(36, 41);
            label11.TabIndex = 75;
            label11.Text = "$";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Times New Roman", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(884, 639);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(36, 41);
            label9.TabIndex = 74;
            label9.Text = "$";
            // 
            // advancePaymentLabel
            // 
            advancePaymentLabel.AutoSize = true;
            advancePaymentLabel.Font = new Font("Times New Roman", 18F, FontStyle.Regular, GraphicsUnit.Point);
            advancePaymentLabel.Location = new Point(929, 639);
            advancePaymentLabel.Margin = new Padding(4, 0, 4, 0);
            advancePaymentLabel.Name = "advancePaymentLabel";
            advancePaymentLabel.Size = new Size(36, 41);
            advancePaymentLabel.TabIndex = 73;
            advancePaymentLabel.Text = "0";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Roboto Condensed", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label10.Location = new Point(615, 640);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new Size(232, 43);
            label10.TabIndex = 72;
            label10.Text = "Adavnace Pay:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Roboto Condensed", 13F, FontStyle.Bold, GraphicsUnit.Point);
            label8.Location = new Point(29, 60);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(201, 32);
            label8.TabIndex = 71;
            label8.Text = "Customer Details:";
            // 
            // rentDateLabel
            // 
            rentDateLabel.AutoSize = true;
            rentDateLabel.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            rentDateLabel.Location = new Point(195, 540);
            rentDateLabel.Margin = new Padding(4, 0, 4, 0);
            rentDateLabel.Name = "rentDateLabel";
            rentDateLabel.Size = new Size(24, 25);
            rentDateLabel.TabIndex = 70;
            rentDateLabel.Text = "0";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Roboto Condensed", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label19.Location = new Point(64, 124);
            label19.Margin = new Padding(4, 0, 4, 0);
            label19.Name = "label19";
            label19.Size = new Size(96, 24);
            label19.TabIndex = 44;
            label19.Text = "Full Name:";
            // 
            // returnDateLabel
            // 
            returnDateLabel.AutoSize = true;
            returnDateLabel.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            returnDateLabel.Location = new Point(569, 544);
            returnDateLabel.Margin = new Padding(4, 0, 4, 0);
            returnDateLabel.Name = "returnDateLabel";
            returnDateLabel.Size = new Size(24, 25);
            returnDateLabel.TabIndex = 69;
            returnDateLabel.Text = "0";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new Font("Roboto Condensed", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label23.Location = new Point(81, 401);
            label23.Margin = new Padding(4, 0, 4, 0);
            label23.Name = "label23";
            label23.Size = new Size(78, 24);
            label23.TabIndex = 46;
            label23.Text = "Car Reg:";
            // 
            // totalPriceLabel
            // 
            totalPriceLabel.AutoSize = true;
            totalPriceLabel.Font = new Font("Times New Roman", 18F, FontStyle.Regular, GraphicsUnit.Point);
            totalPriceLabel.Location = new Point(330, 640);
            totalPriceLabel.Margin = new Padding(4, 0, 4, 0);
            totalPriceLabel.Name = "totalPriceLabel";
            totalPriceLabel.Size = new Size(36, 41);
            totalPriceLabel.TabIndex = 68;
            totalPriceLabel.Text = "0";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Roboto Condensed", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label22.Location = new Point(81, 196);
            label22.Margin = new Padding(4, 0, 4, 0);
            label22.Name = "label22";
            label22.Size = new Size(82, 24);
            label22.TabIndex = 47;
            label22.Text = "Address:";
            // 
            // brandLabel
            // 
            brandLabel.AutoSize = true;
            brandLabel.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            brandLabel.Location = new Point(530, 401);
            brandLabel.Margin = new Padding(4, 0, 4, 0);
            brandLabel.Name = "brandLabel";
            brandLabel.Size = new Size(24, 25);
            brandLabel.TabIndex = 67;
            brandLabel.Text = "0";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Font = new Font("Roboto Condensed", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label24.Location = new Point(732, 124);
            label24.Margin = new Padding(4, 0, 4, 0);
            label24.Name = "label24";
            label24.Size = new Size(112, 24);
            label24.TabIndex = 43;
            label24.Text = "Mobile Num:";
            // 
            // regNumLabel
            // 
            regNumLabel.AutoSize = true;
            regNumLabel.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            regNumLabel.Location = new Point(195, 401);
            regNumLabel.Margin = new Padding(4, 0, 4, 0);
            regNumLabel.Name = "regNumLabel";
            regNumLabel.Size = new Size(24, 25);
            regNumLabel.TabIndex = 66;
            regNumLabel.Text = "0";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Roboto Condensed", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label21.Location = new Point(438, 401);
            label21.Margin = new Padding(4, 0, 4, 0);
            label21.Name = "label21";
            label21.Size = new Size(62, 24);
            label21.TabIndex = 48;
            label21.Text = "Brand:";
            // 
            // driveLicenseLabel
            // 
            driveLicenseLabel.AutoSize = true;
            driveLicenseLabel.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            driveLicenseLabel.Location = new Point(600, 196);
            driveLicenseLabel.Margin = new Padding(4, 0, 4, 0);
            driveLicenseLabel.Name = "driveLicenseLabel";
            driveLicenseLabel.Size = new Size(24, 25);
            driveLicenseLabel.TabIndex = 65;
            driveLicenseLabel.Text = "0";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Roboto Condensed", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label20.Location = new Point(808, 330);
            label20.Margin = new Padding(4, 0, 4, 0);
            label20.Name = "label20";
            label20.Size = new Size(65, 24);
            label20.TabIndex = 49;
            label20.Text = "Model:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Roboto Condensed", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(414, 544);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(110, 24);
            label7.TabIndex = 64;
            label7.Text = "Return Date:";
            label7.Click += label7_Click;
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Font = new Font("Roboto Condensed", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label29.Location = new Point(414, 124);
            label29.Margin = new Padding(4, 0, 4, 0);
            label29.Name = "label29";
            label29.Size = new Size(54, 24);
            label29.TabIndex = 50;
            label29.Text = "CNIC:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Roboto Condensed", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(64, 540);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(93, 24);
            label6.TabIndex = 63;
            label6.Text = "Rent Date:";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Font = new Font("Roboto Condensed", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label28.Location = new Point(81, 640);
            label28.Margin = new Padding(4, 0, 4, 0);
            label28.Name = "label28";
            label28.Size = new Size(161, 43);
            label28.TabIndex = 51;
            label28.Text = "Total Pay:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Roboto Condensed", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(414, 330);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(93, 24);
            label5.TabIndex = 62;
            label5.Text = "Fuel Type:";
            // 
            // fullNameLabel
            // 
            fullNameLabel.AutoSize = true;
            fullNameLabel.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            fullNameLabel.Location = new Point(195, 124);
            fullNameLabel.Margin = new Padding(4, 0, 4, 0);
            fullNameLabel.Name = "fullNameLabel";
            fullNameLabel.Size = new Size(24, 25);
            fullNameLabel.TabIndex = 45;
            fullNameLabel.Text = "0";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Roboto Condensed", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(74, 330);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(85, 24);
            label4.TabIndex = 61;
            label4.Text = "Car Type:";
            // 
            // addressLabel
            // 
            addressLabel.AutoSize = true;
            addressLabel.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            addressLabel.Location = new Point(195, 196);
            addressLabel.Margin = new Padding(4, 0, 4, 0);
            addressLabel.Name = "addressLabel";
            addressLabel.Size = new Size(24, 25);
            addressLabel.TabIndex = 52;
            addressLabel.Text = "0";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Roboto Condensed", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(732, 401);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(124, 24);
            label2.TabIndex = 60;
            label2.Text = "Price Per Day:";
            // 
            // mobNumLabel
            // 
            mobNumLabel.AutoSize = true;
            mobNumLabel.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            mobNumLabel.Location = new Point(882, 124);
            mobNumLabel.Margin = new Padding(4, 0, 4, 0);
            mobNumLabel.Name = "mobNumLabel";
            mobNumLabel.Size = new Size(24, 25);
            mobNumLabel.TabIndex = 53;
            mobNumLabel.Text = "0";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Roboto Condensed", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(414, 196);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(140, 24);
            label1.TabIndex = 59;
            label1.Text = "Driving License:";
            // 
            // cnicLabel
            // 
            cnicLabel.AutoSize = true;
            cnicLabel.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            cnicLabel.Location = new Point(489, 124);
            cnicLabel.Margin = new Padding(4, 0, 4, 0);
            cnicLabel.Name = "cnicLabel";
            cnicLabel.Size = new Size(24, 25);
            cnicLabel.TabIndex = 54;
            cnicLabel.Text = "0";
            // 
            // fuelTypeLabel
            // 
            fuelTypeLabel.AutoSize = true;
            fuelTypeLabel.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            fuelTypeLabel.Location = new Point(530, 330);
            fuelTypeLabel.Margin = new Padding(4, 0, 4, 0);
            fuelTypeLabel.Name = "fuelTypeLabel";
            fuelTypeLabel.Size = new Size(24, 25);
            fuelTypeLabel.TabIndex = 58;
            fuelTypeLabel.Text = "0";
            // 
            // modelLabel
            // 
            modelLabel.AutoSize = true;
            modelLabel.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            modelLabel.Location = new Point(925, 330);
            modelLabel.Margin = new Padding(4, 0, 4, 0);
            modelLabel.Name = "modelLabel";
            modelLabel.Size = new Size(24, 25);
            modelLabel.TabIndex = 55;
            modelLabel.Text = "0";
            // 
            // carTypeLabel
            // 
            carTypeLabel.AutoSize = true;
            carTypeLabel.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            carTypeLabel.Location = new Point(195, 334);
            carTypeLabel.Margin = new Padding(4, 0, 4, 0);
            carTypeLabel.Name = "carTypeLabel";
            carTypeLabel.Size = new Size(24, 25);
            carTypeLabel.TabIndex = 57;
            carTypeLabel.Text = "0";
            // 
            // pricePerDayLabel
            // 
            pricePerDayLabel.AutoSize = true;
            pricePerDayLabel.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            pricePerDayLabel.Location = new Point(925, 401);
            pricePerDayLabel.Margin = new Padding(4, 0, 4, 0);
            pricePerDayLabel.Name = "pricePerDayLabel";
            pricePerDayLabel.Size = new Size(24, 25);
            pricePerDayLabel.TabIndex = 56;
            pricePerDayLabel.Text = "0";
            // 
            // saveBillButton
            // 
            saveBillButton.BackColor = Color.FromArgb(69, 19, 54);
            saveBillButton.Font = new Font("Roboto Condensed", 11F, FontStyle.Bold, GraphicsUnit.Point);
            saveBillButton.ForeColor = SystemColors.ButtonHighlight;
            saveBillButton.Location = new Point(290, 488);
            saveBillButton.Margin = new Padding(4);
            saveBillButton.Name = "saveBillButton";
            saveBillButton.Size = new Size(162, 52);
            saveBillButton.TabIndex = 48;
            saveBillButton.Text = "Save Bill";
            saveBillButton.UseVisualStyleBackColor = false;
            saveBillButton.Click += saveBillButton_Click;
            // 
            // viewBillButton
            // 
            viewBillButton.BackColor = Color.FromArgb(69, 19, 54);
            viewBillButton.Font = new Font("Roboto Condensed", 11F, FontStyle.Bold, GraphicsUnit.Point);
            viewBillButton.ForeColor = SystemColors.ButtonHighlight;
            viewBillButton.Location = new Point(39, 488);
            viewBillButton.Margin = new Padding(4);
            viewBillButton.Name = "viewBillButton";
            viewBillButton.Size = new Size(162, 52);
            viewBillButton.TabIndex = 47;
            viewBillButton.Text = "View Bill";
            viewBillButton.UseVisualStyleBackColor = false;
            viewBillButton.Click += viewBillButton_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Roboto Condensed", 13F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(50, 392);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(96, 32);
            label3.TabIndex = 43;
            label3.Text = "Rent ID:";
            // 
            // rentIDTextBox
            // 
            rentIDTextBox.Location = new Point(195, 388);
            rentIDTextBox.Margin = new Padding(4);
            rentIDTextBox.Multiline = true;
            rentIDTextBox.Name = "rentIDTextBox";
            rentIDTextBox.Size = new Size(256, 36);
            rentIDTextBox.TabIndex = 46;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(69, 19, 54);
            panel3.Dock = DockStyle.Bottom;
            panel3.Location = new Point(0, 888);
            panel3.Margin = new Padding(4);
            panel3.Name = "panel3";
            panel3.Size = new Size(1645, 48);
            panel3.TabIndex = 8;
            // 
            // RentBillPage
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1645, 936);
            Controls.Add(panel1);
            Margin = new Padding(4);
            Name = "RentBillPage";
            Text = "RentBillPage";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel3;
        private Label label3;
        private TextBox rentIDTextBox;
        private Button saveBillButton;
        private Button viewBillButton;
        private GroupBox groupBox1;
        private Label rentDateLabel;
        private Label label19;
        private Label returnDateLabel;
        private Label label23;
        private Label totalPriceLabel;
        private Label label22;
        private Label brandLabel;
        private Label label24;
        private Label regNumLabel;
        private Label label21;
        private Label driveLicenseLabel;
        private Label label20;
        private Label label7;
        private Label label29;
        private Label label6;
        private Label label28;
        private Label label5;
        public Label fullNameLabel;
        private Label label4;
        public Label addressLabel;
        private Label label2;
        private Label mobNumLabel;
        private Label label1;
        private Label cnicLabel;
        private Label fuelTypeLabel;
        private Label modelLabel;
        private Label carTypeLabel;
        private Label pricePerDayLabel;
        private Label label8;
        private Label label11;
        private Label label9;
        private Label advancePaymentLabel;
        private Label label10;
        private Label label14;
        private Label label13;
        private Label label12;
        private Panel panel5;
        private Panel panel4;
        private Panel panel2;
        private Panel panel6;
        private Label label16;
        private Label label15;
    }
}