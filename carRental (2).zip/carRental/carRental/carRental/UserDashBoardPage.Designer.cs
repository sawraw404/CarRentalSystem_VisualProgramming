﻿namespace carRental
{
    partial class UserDashBoardPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserDashBoardPage));
            panel1 = new Panel();
            panel11 = new Panel();
            totalReturnCarsLabel = new Label();
            panel12 = new Panel();
            label5 = new Label();
            pictureBox12 = new PictureBox();
            panel9 = new Panel();
            totalRentCarsLabel = new Label();
            panel10 = new Panel();
            label3 = new Label();
            pictureBox11 = new PictureBox();
            panelDrawer = new Panel();
            label1 = new Label();
            pictureBox10 = new PictureBox();
            flowLayoutPanel1 = new FlowLayoutPanel();
            logoutLabel = new Label();
            returnCarsLabel = new Label();
            manageRentalLabel = new Label();
            manageCustomersLabel = new Label();
            pictureBox8 = new PictureBox();
            btnToggleDrawerClose = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            panel2 = new Panel();
            label2 = new Label();
            label7 = new Label();
            btnToggleDrawerOpen = new PictureBox();
            panel7 = new Panel();
            totalCustomersLabel = new Label();
            panel8 = new Panel();
            label10 = new Label();
            pictureBox9 = new PictureBox();
            panel1.SuspendLayout();
            panel11.SuspendLayout();
            panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            panel9.SuspendLayout();
            panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            panelDrawer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnToggleDrawerClose).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)btnToggleDrawerOpen).BeginInit();
            panel7.SuspendLayout();
            panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(1, 30, 64);
            panel1.Controls.Add(panel11);
            panel1.Controls.Add(panel9);
            panel1.Controls.Add(panelDrawer);
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(panel7);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4, 4, 4, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1645, 936);
            panel1.TabIndex = 3;
            // 
            // panel11
            // 
            panel11.BackColor = Color.FromArgb(46, 97, 145);
            panel11.Controls.Add(totalReturnCarsLabel);
            panel11.Controls.Add(panel12);
            panel11.Location = new Point(1094, 349);
            panel11.Margin = new Padding(4, 4, 4, 4);
            panel11.Name = "panel11";
            panel11.Size = new Size(355, 306);
            panel11.TabIndex = 15;
            // 
            // totalReturnCarsLabel
            // 
            totalReturnCarsLabel.AutoSize = true;
            totalReturnCarsLabel.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            totalReturnCarsLabel.ForeColor = SystemColors.ControlLight;
            totalReturnCarsLabel.Location = new Point(116, 185);
            totalReturnCarsLabel.Margin = new Padding(4, 0, 4, 0);
            totalReturnCarsLabel.Name = "totalReturnCarsLabel";
            totalReturnCarsLabel.Size = new Size(142, 48);
            totalReturnCarsLabel.TabIndex = 13;
            totalReturnCarsLabel.Text = "label11";
            // 
            // panel12
            // 
            panel12.BackColor = Color.FromArgb(69, 19, 54);
            panel12.Controls.Add(label5);
            panel12.Controls.Add(pictureBox12);
            panel12.Location = new Point(0, 0);
            panel12.Margin = new Padding(4, 4, 4, 4);
            panel12.Name = "panel12";
            panel12.Size = new Size(410, 134);
            panel12.TabIndex = 10;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Roboto Condensed", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = SystemColors.ControlLight;
            label5.Location = new Point(43, 34);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(139, 68);
            label5.TabIndex = 1;
            label5.Text = "RETURNED\r\n    CARS";
            // 
            // pictureBox12
            // 
            pictureBox12.Image = (Image)resources.GetObject("pictureBox12.Image");
            pictureBox12.Location = new Point(225, 12);
            pictureBox12.Margin = new Padding(4, 4, 4, 4);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(112, 110);
            pictureBox12.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox12.TabIndex = 0;
            pictureBox12.TabStop = false;
            // 
            // panel9
            // 
            panel9.BackColor = Color.FromArgb(46, 97, 145);
            panel9.Controls.Add(totalRentCarsLabel);
            panel9.Controls.Add(panel10);
            panel9.Location = new Point(682, 349);
            panel9.Margin = new Padding(4, 4, 4, 4);
            panel9.Name = "panel9";
            panel9.Size = new Size(355, 306);
            panel9.TabIndex = 14;
            // 
            // totalRentCarsLabel
            // 
            totalRentCarsLabel.AutoSize = true;
            totalRentCarsLabel.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            totalRentCarsLabel.ForeColor = SystemColors.ControlLight;
            totalRentCarsLabel.Location = new Point(118, 185);
            totalRentCarsLabel.Margin = new Padding(4, 0, 4, 0);
            totalRentCarsLabel.Name = "totalRentCarsLabel";
            totalRentCarsLabel.Size = new Size(142, 48);
            totalRentCarsLabel.TabIndex = 13;
            totalRentCarsLabel.Text = "label11";
            // 
            // panel10
            // 
            panel10.BackColor = Color.FromArgb(69, 19, 54);
            panel10.Controls.Add(label3);
            panel10.Controls.Add(pictureBox11);
            panel10.Location = new Point(0, 0);
            panel10.Margin = new Padding(4, 4, 4, 4);
            panel10.Name = "panel10";
            panel10.Size = new Size(410, 134);
            panel10.TabIndex = 10;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Roboto Condensed", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = SystemColors.ControlLight;
            label3.Location = new Point(28, 49);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(177, 34);
            label3.TabIndex = 1;
            label3.Text = "RENTED CARS";
            // 
            // pictureBox11
            // 
            pictureBox11.Image = (Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new Point(225, 12);
            pictureBox11.Margin = new Padding(4, 4, 4, 4);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(112, 110);
            pictureBox11.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox11.TabIndex = 0;
            pictureBox11.TabStop = false;
            // 
            // panelDrawer
            // 
            panelDrawer.BackColor = Color.FromArgb(24, 111, 101);
            panelDrawer.Controls.Add(label1);
            panelDrawer.Controls.Add(pictureBox10);
            panelDrawer.Controls.Add(flowLayoutPanel1);
            panelDrawer.Controls.Add(logoutLabel);
            panelDrawer.Controls.Add(returnCarsLabel);
            panelDrawer.Controls.Add(manageRentalLabel);
            panelDrawer.Controls.Add(manageCustomersLabel);
            panelDrawer.Controls.Add(pictureBox8);
            panelDrawer.Controls.Add(btnToggleDrawerClose);
            panelDrawer.Controls.Add(pictureBox5);
            panelDrawer.Controls.Add(pictureBox4);
            panelDrawer.Controls.Add(pictureBox3);
            panelDrawer.Location = new Point(0, 0);
            panelDrawer.Margin = new Padding(4, 4, 4, 4);
            panelDrawer.Name = "panelDrawer";
            panelDrawer.Size = new Size(0, 936);
            panelDrawer.TabIndex = 8;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top;
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.ControlLight;
            label1.Location = new Point(-130, 15);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(260, 108);
            label1.TabIndex = 2;
            label1.Text = "CAR RENTAL\r\n    SYSTEM";
            // 
            // pictureBox10
            // 
            pictureBox10.Image = Properties.Resources.splash;
            pictureBox10.Location = new Point(139, 154);
            pictureBox10.Margin = new Padding(4, 4, 4, 4);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(168, 111);
            pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox10.TabIndex = 15;
            pictureBox10.TabStop = false;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.BackColor = SystemColors.ControlLight;
            flowLayoutPanel1.Location = new Point(30, 288);
            flowLayoutPanel1.Margin = new Padding(4, 4, 4, 4);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(388, 1);
            flowLayoutPanel1.TabIndex = 14;
            // 
            // logoutLabel
            // 
            logoutLabel.AutoSize = true;
            logoutLabel.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            logoutLabel.ForeColor = SystemColors.ControlLight;
            logoutLabel.Location = new Point(228, 832);
            logoutLabel.Margin = new Padding(4, 0, 4, 0);
            logoutLabel.Name = "logoutLabel";
            logoutLabel.Size = new Size(95, 32);
            logoutLabel.TabIndex = 13;
            logoutLabel.Text = "Logout";
            logoutLabel.Click += logoutLabel_Click;
            // 
            // returnCarsLabel
            // 
            returnCarsLabel.AutoSize = true;
            returnCarsLabel.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            returnCarsLabel.ForeColor = SystemColors.ControlLight;
            returnCarsLabel.Location = new Point(230, 686);
            returnCarsLabel.Margin = new Padding(4, 0, 4, 0);
            returnCarsLabel.Name = "returnCarsLabel";
            returnCarsLabel.Size = new Size(91, 32);
            returnCarsLabel.TabIndex = 11;
            returnCarsLabel.Text = "Return";
            returnCarsLabel.Click += returnCarsLabel_Click;
            // 
            // manageRentalLabel
            // 
            manageRentalLabel.AutoSize = true;
            manageRentalLabel.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            manageRentalLabel.ForeColor = SystemColors.ControlLight;
            manageRentalLabel.Location = new Point(228, 549);
            manageRentalLabel.Margin = new Padding(4, 0, 4, 0);
            manageRentalLabel.Name = "manageRentalLabel";
            manageRentalLabel.Size = new Size(86, 32);
            manageRentalLabel.TabIndex = 10;
            manageRentalLabel.Text = "Rental";
            manageRentalLabel.Click += manageRentalLabel_Click;
            // 
            // manageCustomersLabel
            // 
            manageCustomersLabel.AutoSize = true;
            manageCustomersLabel.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            manageCustomersLabel.ForeColor = SystemColors.ControlLight;
            manageCustomersLabel.Location = new Point(228, 409);
            manageCustomersLabel.Margin = new Padding(4, 0, 4, 0);
            manageCustomersLabel.Name = "manageCustomersLabel";
            manageCustomersLabel.Size = new Size(135, 32);
            manageCustomersLabel.TabIndex = 9;
            manageCustomersLabel.Text = "Customers";
            manageCustomersLabel.Click += manageCustomersLabel_Click;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = Properties.Resources.logout;
            pictureBox8.Location = new Point(75, 826);
            pictureBox8.Margin = new Padding(4, 4, 4, 4);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(45, 46);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 7;
            pictureBox8.TabStop = false;
            // 
            // btnToggleDrawerClose
            // 
            btnToggleDrawerClose.Image = Properties.Resources.burger;
            btnToggleDrawerClose.Location = new Point(389, 15);
            btnToggleDrawerClose.Margin = new Padding(4, 4, 4, 4);
            btnToggleDrawerClose.Name = "btnToggleDrawerClose";
            btnToggleDrawerClose.Size = new Size(45, 46);
            btnToggleDrawerClose.SizeMode = PictureBoxSizeMode.StretchImage;
            btnToggleDrawerClose.TabIndex = 5;
            btnToggleDrawerClose.TabStop = false;
            btnToggleDrawerClose.Click += btnToggleDrawerClose_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources._return;
            pictureBox5.Location = new Point(78, 681);
            pictureBox5.Margin = new Padding(4, 4, 4, 4);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(45, 46);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 4;
            pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.rental;
            pictureBox4.Location = new Point(75, 545);
            pictureBox4.Margin = new Padding(4, 4, 4, 4);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(45, 46);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 3;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.customer1;
            pictureBox3.Location = new Point(75, 405);
            pictureBox3.Margin = new Padding(4, 4, 4, 4);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(45, 46);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 2;
            pictureBox3.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(69, 19, 54);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(label7);
            panel2.Controls.Add(btnToggleDrawerOpen);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(4, 4, 4, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(1645, 170);
            panel2.TabIndex = 7;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Top;
            label2.AutoSize = true;
            label2.Font = new Font("Roboto Condensed", 22F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = SystemColors.ControlLight;
            label2.Location = new Point(658, 36);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(503, 53);
            label2.TabIndex = 4;
            label2.Text = "THE CAR RENTAL SYSTAM ";
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.Top;
            label7.AutoSize = true;
            label7.Font = new Font("Roboto Condensed", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ForeColor = SystemColors.ControlLight;
            label7.Location = new Point(798, 100);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(206, 43);
            label7.TabIndex = 3;
            label7.Text = "DASHBOARD";
            // 
            // btnToggleDrawerOpen
            // 
            btnToggleDrawerOpen.Image = Properties.Resources.burger;
            btnToggleDrawerOpen.Location = new Point(15, 15);
            btnToggleDrawerOpen.Margin = new Padding(4, 4, 4, 4);
            btnToggleDrawerOpen.Name = "btnToggleDrawerOpen";
            btnToggleDrawerOpen.Size = new Size(45, 46);
            btnToggleDrawerOpen.SizeMode = PictureBoxSizeMode.StretchImage;
            btnToggleDrawerOpen.TabIndex = 0;
            btnToggleDrawerOpen.TabStop = false;
            btnToggleDrawerOpen.Click += btnToggleDrawerOpen_Click;
            // 
            // panel7
            // 
            panel7.BackColor = Color.FromArgb(46, 97, 145);
            panel7.Controls.Add(totalCustomersLabel);
            panel7.Controls.Add(panel8);
            panel7.Location = new Point(269, 349);
            panel7.Margin = new Padding(4, 4, 4, 4);
            panel7.Name = "panel7";
            panel7.Size = new Size(355, 306);
            panel7.TabIndex = 13;
            // 
            // totalCustomersLabel
            // 
            totalCustomersLabel.AutoSize = true;
            totalCustomersLabel.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            totalCustomersLabel.ForeColor = SystemColors.ControlLight;
            totalCustomersLabel.Location = new Point(131, 185);
            totalCustomersLabel.Margin = new Padding(4, 0, 4, 0);
            totalCustomersLabel.Name = "totalCustomersLabel";
            totalCustomersLabel.Size = new Size(142, 48);
            totalCustomersLabel.TabIndex = 13;
            totalCustomersLabel.Text = "label11";
            // 
            // panel8
            // 
            panel8.BackColor = Color.FromArgb(69, 19, 54);
            panel8.Controls.Add(label10);
            panel8.Controls.Add(pictureBox9);
            panel8.Location = new Point(0, 0);
            panel8.Margin = new Padding(4, 4, 4, 4);
            panel8.Name = "panel8";
            panel8.Size = new Size(410, 134);
            panel8.TabIndex = 10;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Roboto Condensed", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label10.ForeColor = SystemColors.ControlLight;
            label10.Location = new Point(25, 58);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new Size(160, 34);
            label10.TabIndex = 1;
            label10.Text = "CUSTOMERS";
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(225, 12);
            pictureBox9.Margin = new Padding(4, 4, 4, 4);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(112, 110);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 0;
            pictureBox9.TabStop = false;
            // 
            // UserDashBoardPage
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1645, 936);
            Controls.Add(panel1);
            Margin = new Padding(4, 4, 4, 4);
            Name = "UserDashBoardPage";
            Text = "UserDashBoardPage";
            Load += UserDashBoardPage_Load;
            panel1.ResumeLayout(false);
            panel11.ResumeLayout(false);
            panel11.PerformLayout();
            panel12.ResumeLayout(false);
            panel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            panel9.ResumeLayout(false);
            panel9.PerformLayout();
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            panelDrawer.ResumeLayout(false);
            panelDrawer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnToggleDrawerClose).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)btnToggleDrawerOpen).EndInit();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel11;
        private Label totalReturnCarsLabel;
        private Panel panel12;
        private Label label5;
        private PictureBox pictureBox12;
        private Panel panel9;
        private Label totalRentCarsLabel;
        private Panel panel10;
        private Label label3;
        private PictureBox pictureBox11;
        private Panel panel7;
        private Label totalCustomersLabel;
        private Panel panel8;
        private Label label10;
        private PictureBox pictureBox9;
        private Panel panelDrawer;
        private Label label1;
        private PictureBox pictureBox10;
        private FlowLayoutPanel flowLayoutPanel1;
        private Label logoutLabel;
        private Label returnCarsLabel;
        private Label manageRentalLabel;
        private Label manageCustomersLabel;
        private PictureBox pictureBox8;
        private PictureBox btnToggleDrawerClose;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private Panel panel2;
        private PictureBox btnToggleDrawerOpen;
        private Label label7;
        private Label label2;
    }
}